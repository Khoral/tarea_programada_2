import java.util.List;
import java.util.LinkedList;

public class PoloNorteInc {
	public List<String> children=new LinkedList();
	
}
