

public class regalo {
	String nombreRegalo;
	String marca;
	int precio;
	int edadNecesaria;
	
	
    
}
